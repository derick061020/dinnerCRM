<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\ProductTimeslot;
use App\Models\Product;
use App\Models\Inventory;
use App\Services\OrderDataMigrationService;
use Carbon\Carbon;
use WpOrg\Requests\Requests;
use Illuminate\Support\Facades\Log;

class WooOrderController extends Controller
{
    public function syncWebhook(Request $request)
    {
        // Registrar siempre la request completa
        Log::info('WooCommerce webhook recibido', ['payload' => $request->all()]);

        // Manejar challenge o payload mínimo
        if ($request->has('webhook_id') && count($request->all()) === 1) {
            return response()->json(['success' => true]);
        }

        try {
            $payload = $request->all();

            // Validar que sea un pedido
            if (!isset($payload['id'], $payload['status'], $payload['line_items'])) {
                throw new \Exception('Payload WooCommerce inválido');
            }

            // Obtener detalles completos usando getOrderDetails para appointment
            $orderDetails = $this->getOrderDetails($payload['id']);
            
            // Logear TODO el response para debugging completo
            Log::info('Response completo de getOrderDetails', [
                'order_id' => $payload['id'],
                'response_type' => gettype($orderDetails),
                'response_success' => $orderDetails->getData()->success ?? false,
                'response_message' => $orderDetails->getData()->message ?? 'No message',
                'response_data_type' => gettype($orderDetails->getData()->data),
                'response_data' => $orderDetails->getData()->data,
                'response_order_notes_type' => gettype($orderDetails->getData()->order_notes),
                'response_order_notes' => $orderDetails->getData()->order_notes,
                'response_original' => $orderDetails->original ?? 'No original'
            ]);
            
            if (!$orderDetails->getData()->success) {
                Log::error('No se pudieron obtener detalles de la orden', ['order_id' => $payload['id']]);
                return response()->json(['success' => false, 'message' => 'No se obtuvieron detalles de la orden' ]);
            }

            $detailsData = $orderDetails->getData()->data;
            $dataDetails = $orderDetails->getData();
            
            // Logear los datos obtenidos para debugging
            Log::info('Datos de orden obtenidos', [
                'order_id' => $payload['id'],
                'details_data_type' => gettype($detailsData),
                'details_data' => $detailsData,
                'line_items_count' => isset($detailsData->line_items) ? count($detailsData->line_items) : 0
            ]);
            
            // Extraer appointment_id de las order notes
            $appointmentId = null;
            $bookingStart = null;
            $bookingEnd = null;
            
            // Acceder correctamente a order_notes desde el objeto anidado
            $orderNotes = $dataDetails->order_notes ?? [];
            
            foreach ($orderNotes as $note) {
                if (isset($note->note) && preg_match('/Appointment #(\d+)/', $note->note, $matches)) {
                    $appointmentId = $matches[1];
                    
                    Log::info('Appointment ID encontrado en order notes', [
                        'appointment_id' => $appointmentId,
                        'note_text' => $note->note
                    ]);
                    
                    break; // Salir del loop una vez encontrado
                }
            }

            
            // Si tenemos appointment_id, obtener detalles del appointment
            if ($appointmentId) {
                try {
                    // Usar el endpoint correcto que funciona
                    $appointmentUrl = config('woocommerce.base_url') . "/wp-json/wc-appointments/v1/appointments/{$appointmentId}";
                    $auth = config('woocommerce.auth');
                    
                    Log::info('Obteniendo appointment con endpoint correcto', [
                        'appointment_id' => $appointmentId,
                        'appointment_url' => $appointmentUrl
                    ]);
                    
                    $appointmentResponse = Requests::get($appointmentUrl, [
                        'Authorization' => $auth,
                        'Content-Type' => 'application/json',
                        'Accept' => 'application/json'
                    ]);

                    // Logear response completo del appointment
                    Log::info('Response de appointment endpoint correcto', [
                        'appointment_id' => $appointmentId,
                        'response_success' => $appointmentResponse->success,
                        'response_status_code' => $appointmentResponse->status_code ?? 'no status',
                        'response_body_type' => gettype($appointmentResponse->body),
                        'response_body' => $appointmentResponse->body
                    ]);

                    if ($appointmentResponse->success) {
                        $appointmentData = json_decode($appointmentResponse->body, true);
                        $bookingStart = $appointmentData['start'] ?? $appointmentData['date_start'] ?? null;
                        $bookingEnd = $appointmentData['end'] ?? $appointmentData['date_end'] ?? null;
                        
                        Log::info('Appointment obtenido exitosamente', [
                            'appointment_id' => $appointmentId,
                            'appointment_data' => $appointmentData,
                            'start' => $bookingStart,
                            'end' => $bookingEnd
                        ]);
                    } else {
                        Log::error('Error obteniendo appointment', [
                            'appointment_id' => $appointmentId,
                            'status_code' => $appointmentResponse->status_code ?? 'unknown',
                            'body' => $appointmentResponse->body ?? 'no body'
                        ]);
                    }
                } catch (\Exception $e) {
                    Log::error('Error obteniendo appointment', [
                        'appointment_id' => $appointmentId,
                        'error' => $e->getMessage(),
                        'trace' => $e->getTraceAsString()
                    ]);
                }
            } else {
                Log::warning('No se encontró appointment_id', [
                    'order_id' => $payload['id'],
                    'line_items_count' => isset($detailsData->line_items) ? count($detailsData->line_items) : 0
                ]);
            }

            // Extraer el product_id del primer line_item
            $product_id = null;
            if (!empty($payload['line_items'])) {
                $first_item = $payload['line_items'][0];
                $product_id = $first_item['product_id'] ?? null;
            }

            // Guardar pedido en nuestra BD usando el servicio de migración
            try {
                $migrationService = new OrderDataMigrationService();
                
                // Preparar datos completos para el servicio
                $completeData = [
                    'success' => true,
                    'data' => $detailsData,
                    'order_notes' => $orderNotes
                ];
                
                $order = $migrationService->createOrderFromWooData($completeData);
                
                // Agregar campos adicionales que no están en el servicio
                $order->booking_start = $bookingStart ? Carbon::parse($bookingStart) : null;
                $order->booking_end = $bookingEnd ? Carbon::parse($bookingEnd) : null;
                $order->created_at = Carbon::parse($payload['date_created']);
                $order->updated_at = Carbon::parse($payload['date_modified']);
                
                // Guardar manteniendo el JSON como respaldo (opcional)
                $order->data = $dataDetails;
                
                $order->save();
                
            } catch (\Exception $e) {
                Log::error('Error creando orden con OrderDataMigrationService', [
                    'error' => $e->getMessage(),
                    'order_id' => $payload['id']
                ]);
                
                // Fallback al método anterior si falla
                $order = Order::updateOrCreate(
                    ['woocommerce_order_id' => $payload['id']],
                    [
                        'product_id' => $product_id,
                        'status' => $payload['status'],
                        'customer_name' => $payload['billing']['first_name'] ?? null,
                        'customer_email' => $payload['billing']['email'] ?? null,
                        'total' => $payload['total'] ?? 0,
                        'booking_start' => $bookingStart ? Carbon::parse($bookingStart) : null,
                        'booking_end' => $bookingEnd ? Carbon::parse($bookingEnd) : null,
                        'data' => $dataDetails,
                        'created_at' => Carbon::parse($payload['date_created']),
                        'updated_at' => Carbon::parse($payload['date_modified']),
                    ]
                );
            }

            Log::info('Orden sincronizada exitosamente', [
                'order_id' => $payload['id'],
                'appointment_id' => $appointmentId,
                'booking_start' => $bookingStart,
                'booking_end' => $bookingEnd
            ]);


            return response()->json(['success' => true]);
        } catch (\Throwable $e) {
            // Guardar el error y la request completa
            Log::error('Error al procesar webhook WooCommerce', [
                'error' => $e->getMessage(),
                'payload' => $request->all()
            ]);
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    // 2. Endpoint para obtener detalles completos desde WooCommerce
    public function getOrderDetails($woocommerce_order_id)
    {
        $url = config('woocommerce.base_url') . "/wp-json/wc/v3/orders/{$woocommerce_order_id}";

        $response = Requests::get($url, [
            'Authorization' => config('woocommerce.auth')
        ]);

        if(!$response->success){
            return response()->json(['success'=>false,'message'=>'No se pudo obtener datos de WooCommerce']);
        }

        $body = json_decode($response->body, true);

        // Obtener las order notes del pedido
        $notes_url = config('woocommerce.base_url') . "/wp-json/wc/v3/orders/{$woocommerce_order_id}/notes";

        $notes_response = Requests::get($notes_url, [
            'Authorization' => config('woocommerce.auth')
        ]);

        $order_notes = [];
        if($notes_response->success){
            $order_notes = json_decode($notes_response->body, true);
        }

        return response()->json([
            'success'=>true,
            'data'=>$body,
            'order_notes'=>$order_notes
        ]);
    }

    // 3. Actualizar disponibilidad del producto
    protected function updateProductAvailability($wordpress_product_id, $date = null, $quantity = 1)
    {
        if(!$wordpress_product_id) return;

        $product = Product::where('wordpress_product_id', $wordpress_product_id)->first();
        if(!$product) return;

        $date = $date ? Carbon::parse($date) : Carbon::today();
        $weekday = $date->dayOfWeek;

        $slots = ProductTimeslot::where('product_id', $product->id)
            ->where('weekday', $weekday)
            ->where('active', true)
            ->get();

        foreach($slots as $slot){
            $inventory = Inventory::firstOrCreate(
                [
                    'product_id' => $product->id,
                    'date' => $date->toDateString(),
                    'start_time' => $slot->start_time
                ],
                [
                    'capacity_total' => $product->default_capacity,
                    'capacity_used' => 0
                ]
            );

            $inventory->capacity_used += $quantity;
            $inventory->save();
        }
    }
}